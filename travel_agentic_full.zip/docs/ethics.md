# Ethics & Responsible Design

- Data minimization: store only necessary personal data. Provide retention policy and TTLs.
- Privacy: encrypt PII at rest and in transit. Allow user to delete profile and trip history.
- Explainability: provide reasons and weighted scores for recommendations.
- Safety: refuse to recommend trips in hazardous conditions; show alerts.
- Fairness: avoid discriminatory personalization; allow user overrides for cost/comfort tradeoffs.
