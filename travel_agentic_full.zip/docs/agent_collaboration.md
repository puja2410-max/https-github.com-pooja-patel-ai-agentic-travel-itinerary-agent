# Agent Collaboration Model

- Use asynchronous message bus topics/queues:
  - planning.request (orchestrator -> agents)
  - agent.<name>.response (agent -> orchestrator/planner)
  - events.disruption (external events -> orchestrator -> replanner)

- Agents are idempotent: each request has a job_id; responses include job_id and partial results.
- Planner aggregates partial responses using timeouts and then finalizes itinerary.
