# Future Enhancements

- Integrate real-time APIs (OpenWeatherMap, Google Maps/Traffic, HERE)
- Add an explainability module producing user-friendly rationales (LLM summarization)
- Train preference models using reinforcement learning or contextual bandits
- Add booking integrations with partner APIs (OTAs)
