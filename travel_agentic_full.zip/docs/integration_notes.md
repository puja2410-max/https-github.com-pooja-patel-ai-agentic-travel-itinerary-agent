# Integration Notes

Replace stubs with real API integrations:
- Weather: OpenWeatherMap OneCall or Meteostat. Use lat/lon for accurate forecasts.
- Maps/Traffic: Google Maps Directions API, Directions + Distance Matrix + Traffic. HERE or Mapbox as alternatives.
- Holidays: PublicHoliday APIs or curated calendars per destination.
- Pricing/Booking: OTA APIs or partner affiliate feeds.

Pattern:
1. Create a wrapper client in `agents/clients/` to abstract API calls.
2. Add caching with Redis for repeated requests.
3. Use RabbitMQ topics to fan-out requests for long-running computations.
