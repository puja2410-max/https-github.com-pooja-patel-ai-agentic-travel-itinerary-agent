# PEAS Framework

Performance measures:
- Constraint satisfaction rate (budget, travel time)
- User-rated relevance / satisfaction
- Replanning success (handling disruptions)
- Latency for providing recommendations

Environment:
- Dynamic (weather, traffic, prices)
- Multi-user, distributed APIs with rate limits and partial observability

Actuators:
- Suggested itineraries (ranked)
- Notifications, booking links, suggested rebooking

Sensors:
- Weather APIs, Traffic APIs, Holiday calendars, Price feeds, User feedback

