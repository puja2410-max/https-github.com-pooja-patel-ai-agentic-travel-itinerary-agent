# System Architecture (High level)

Components:
- API / UI (FastAPI) - receives user requests and shows itineraries
- Orchestrator - coordinates planning jobs, publishes/consumes messages
- Message Bus - RabbitMQ for event-driven sub-agent calls
- Sub-agents (microservices or modules): WeatherAgent, HolidayAgent, TransportAgent, BudgetAgent, PlannerAgent, PreferenceAgent, ReplannerAgent
- Data Stores: Redis (cache), Postgres (persistent user profiles & itineraries)
- ML / Scoring Service: optional service hosting models for preference learning & scoring

Control Flow:
1. User submits trip request to API
2. Orchestrator creates planning job and publishes messages to message bus
3. Sub-agents subscribe to relevant queues, fetch external data (APIs), produce ranked options
4. PlannerAgent aggregates, runs multi-objective optimization, composes itinerary
5. ReplannerAgent listens for events (flight delays, weather alerts) and re-runs planning with constraints

Diagram (simple ASCII):

  [User/API] -> [Orchestrator] -> [Message Bus] -> [Sub-Agents]
                                     \-> [Planner] -> [DB / Notifications]

