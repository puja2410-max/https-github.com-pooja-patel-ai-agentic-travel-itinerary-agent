# Use Cases

Simple:
- Weather-based adjustment: If high rain probability, prefer indoor activities and show alternative months.
- Budget-based selection: Given budget, optimize lodging + transport + activities.
- Road travel: Suggest stopovers based on travel time and road conditions.
- Event detection: Detect peak-season (e.g., New Year) and warn of price surge; recommend early booking.

Advanced:
- Dynamic replanning: Handle flight delays or weather alerts by re-ordering activities, changing bookings.
- Multi-agent collaboration: Use message bus to orchestrate asynchronous responses from agents.
- Preference learning: Use logged behavior + lightweight RL or bandit for personalization.
- Multi-objective optimization: Optimize for cost vs comfort using weighted scoring or Pareto front.
