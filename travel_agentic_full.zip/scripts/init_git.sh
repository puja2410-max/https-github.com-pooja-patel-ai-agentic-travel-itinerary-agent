#!/usr/bin/env bash
set -e
if [ ! -d ".git" ]; then
  git init
  git add .
  git commit -m "Initial commit - Agentic Travel Itinerary Agent scaffold"
  echo "Git repo initialized and initial commit created."
else
  echo "Git already initialized."
fi
