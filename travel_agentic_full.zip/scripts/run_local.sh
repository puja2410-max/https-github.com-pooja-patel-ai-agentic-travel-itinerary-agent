#!/usr/bin/env bash
set -e
echo "Starting API locally on http://127.0.0.1:8000"
uvicorn orchestrator.api:app --reload --port 8000
