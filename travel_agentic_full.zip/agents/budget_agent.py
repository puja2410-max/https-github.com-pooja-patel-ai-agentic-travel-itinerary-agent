class BudgetAgent:
    def __init__(self, price_feeds=None):
        self.price_feeds = price_feeds or {}
    def estimate_costs(self, nights, transport_cost, daily_activity_budget, surge_factor=1.0):
        avg_stay = 3000
        lodging = nights * avg_stay
        activities = nights * daily_activity_budget
        total = (lodging + activities + transport_cost) * surge_factor
        return {'lodging':lodging,'activities':activities,'transport':transport_cost,'total':round(total,2)}
    def fit_within_budget(self, budget, estimate):
        return estimate['total'] <= budget
