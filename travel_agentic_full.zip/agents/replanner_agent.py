class ReplannerAgent:
    def __init__(self):
        pass
    def handle_disruption(self, itinerary, disruption_event):
        # Example: flight delay -> push activities later or suggest alternatives
        # Real implementation: check booking rules, contact providers, suggest options
        return {'status':'replanned','reason':str(disruption_event),'new_itinerary':itinerary}
