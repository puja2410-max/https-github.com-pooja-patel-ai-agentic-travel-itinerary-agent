class PlannerAgent:
    def __init__(self):
        pass
    def multi_objective_score(self, weather_score, comfort_score, cost_score, weights=None):
        w = weights or {'weather':0.3,'comfort':0.4,'cost':0.3}
        score = weather_score * w['weather'] + comfort_score * w['comfort'] + cost_score * w['cost']
        return score
    def compose_itinerary(self, job_id, parts, explanation=True):
        # parts contains agent outputs and chosen plan
        return {'job_id':job_id,'itinerary':parts,'explanation': 'See component scores' if explanation else None}
