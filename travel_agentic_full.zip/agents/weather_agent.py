import datetime
class WeatherAgent:
    def __init__(self, api_client=None):
        self.api_client = api_client
    def fetch_weather(self, location, start_date, end_date):
        # TODO: Replace with real Weather API integration (OpenWeatherMap / Meteostat)
        if start_date.month == 7:
            return {'condition':'monsoon','rain_prob':0.85,'advice':'indoor'}
        if start_date.month in (12,1,2):
            return {'condition':'sunny','rain_prob':0.05,'advice':'outdoor'}
        return {'condition':'mixed','rain_prob':0.25,'advice':'mixed'}
    def assess_suitability(self, weather_info, preferences):
        score = 100 - int(weather_info.get('rain_prob',0)*100)
        if preferences.get('prefer_outdoor') and weather_info.get('rain_prob',0) > 0.5:
            score -= 25
        return max(0,score)
