from fastapi import FastAPI
from pydantic import BaseModel
import datetime
from .main import plan_trip

app = FastAPI(title='Agentic Travel Planner API')

class TripRequest(BaseModel):
    user_id: str | None = None
    origin: str
    destination: str
    start_date: datetime.date
    nights: int
    budget: float
    transport: str = 'air'
    daily_activity_budget: float = 1500.0
    preferences: dict | None = None

@app.post('/plan')
def plan(req: TripRequest):
    request = req.dict()
    itinerary = plan_trip(request)
    return itinerary
