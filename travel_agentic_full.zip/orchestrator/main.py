import uuid, datetime, json, os
from agents.weather_agent import WeatherAgent
from agents.holiday_agent import HolidayAgent
from agents.transport_agent import TransportAgent
from agents.budget_agent import BudgetAgent
from agents.preference_agent import PreferenceAgent
from agents.planner_agent import PlannerAgent
from agents.replanner_agent import ReplannerAgent

def plan_trip(request):
    job_id = str(uuid.uuid4())
    # Instantiate agents
    wa = WeatherAgent()
    ha = HolidayAgent()
    ta = TransportAgent()
    ba = BudgetAgent()
    pa = PreferenceAgent()
    pl = PlannerAgent()
    rp = ReplannerAgent()

    start = request['start_date']
    nights = request['nights']
    prefs = pa.infer_preferences(request.get('user_id'), request.get('preferences'))

    w_info = wa.fetch_weather(request['destination'], start, start)
    weather_score = wa.assess_suitability(w_info, prefs)

    h_info = ha.fetch_holidays(request['destination'], start, start)

    t_info = ta.estimate_travel(request.get('origin','home'), request['destination'], mode=request.get('transport','air'))
    road = None
    if t_info.get('mode') == 'road':
        road = ta.check_road_conditions(None)
        t_info['road'] = road

    cost = ba.estimate_costs(nights, t_info.get('estimated_cost',0), request.get('daily_activity_budget',1500), h_info.get('surge_factor',1.0))
    within_budget = ba.fit_within_budget(request['budget'], cost)

    score = pl.multi_objective_score(weather_score, 70 if within_budget else 40, max(0, 100 - (cost['total']/1000)))
    itinerary = pl.compose_itinerary(job_id, {
        'weather': w_info,
        'holiday': h_info,
        'transport': t_info,
        'cost': cost,
        'prefs': prefs,
        'score': score
    })
    return itinerary

def main():
    scenarios = [
        {'name':'Goa July (Weather)', 'destination':'Goa', 'origin':'Mumbai', 'start_date': datetime.date(2025,7,10), 'nights':3, 'budget':25000, 'transport':'air', 'daily_activity_budget':1500, 'preferences':{'prefer_outdoor':True}},
        {'name':'Budget 25k', 'destination':'Goa', 'origin':'Pune', 'start_date': datetime.date(2025,11,10), 'nights':3, 'budget':25000, 'transport':'road', 'daily_activity_budget':1000, 'preferences':{}},
        {'name':'NewYear Road', 'destination':'Goa', 'origin':'Bangalore', 'start_date': datetime.date(2025,12,28), 'nights':4, 'budget':40000, 'transport':'road', 'daily_activity_budget':1500, 'preferences':{}},
    ]
    results = {}
    for s in scenarios:
        print('Running', s['name'])
        res = plan_trip(s)
        results[s['name']] = res
        print(json.dumps(res, default=str, indent=2))
    outdir = os.path.join(os.path.dirname(__file__), '..', 'examples')
    os.makedirs(outdir, exist_ok=True)
    with open(os.path.join(outdir, 'sample_runs.json'),'w') as f:
        json.dump(results, f, default=str, indent=2)

if __name__ == '__main__':
    main()
