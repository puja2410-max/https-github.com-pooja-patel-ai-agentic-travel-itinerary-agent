from orchestrator.main import plan_trip
import datetime
def test_basic_plan():
    req = {'user_id':None,'origin':'CityA','destination':'Goa','start_date': datetime.date(2025,11,10),'nights':2,'budget':20000,'transport':'air','daily_activity_budget':1000,'preferences':{}}
    res = plan_trip(req)
    assert 'itinerary' in res
