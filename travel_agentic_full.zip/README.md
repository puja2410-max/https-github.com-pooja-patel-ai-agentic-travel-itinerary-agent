# Agentic Travel Itinerary Agent (Full Scaffold)

This repository contains a complete scaffold for an Agentic AI Travel Itinerary Agent that plans optimized
travel itineraries considering weather, budget, transport, holidays, road conditions, and user preferences.

Structure highlights:
- `agents/` - modular sub-agents (weather, holiday, transport, budget, planner, preference learning, replanner)
- `orchestrator/` - job orchestration, message bus interface, API server (FastAPI stub)
- `infra/` - docker-compose for local development (RabbitMQ message bus, Redis cache, optional Postgres)
- `docs/` - architecture, PEAS, use-cases, ethics, agent collaboration model
- `ci/` - GitHub Actions workflow to run linters/tests
- `examples/` - sample scenarios and outputs
- `scripts/` - helper scripts (init git, run locally)

Quick start (local):
1. Install Python 3.10+, create virtualenv, install dependencies: `pip install -r requirements.txt`
2. Start infra locally (optional): `docker-compose -f infra/docker-compose.yml up -d`
3. Run orchestrator example: `python orchestrator/main.py`

Notes:
- External API calls (weather, maps) are stubbed and clearly marked. Replace with real clients and add API keys.
- This scaffold intentionally uses a hybrid architecture: rule-based checks + scoring + optional ML modules.

